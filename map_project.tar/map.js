/* 
  Map object as specified for javascript competency test from STR.
  I have deliberately used no external libraries or frameworks for this, as no
  such allowance was specified.

  Requirements as given:
 
    Please define a new JavaScript object called ‘Map’ that can be instantiated
    with ‘new’, using its constructor. The constructor takes one parameter - this
    list of cities and their latitudes and longitudes:


    “Nashville, TN”, 36.17, 86.78

    “New York, NY”, 40.71, 74.00

    “Atlanta, GA”, 33.75, 84.39

    “Denver, CO”, 39.74, 104.98

    “Seattle, WA”, 47.61, 122.33

    “Los Angeles, CA”, 34.05, 118.24

    “Memphis, TN”, 35.15, 90.05


    This ‘Map’ object should have the following methods:


    1)      Return the name of the northernmost, easternmost, southernmost or
    westernmost city from the list, as requested by the caller.


    2)      Pass longitude and latitude as parameters, and return the name of the
    city that is closest to that location.


    3)      Return a single string containing just the state abbreviations from the
    list of cities, each separated by a space. The method should eliminate
    duplicate states. The result string should not have leading or trailing spaces.


    4)      Return an object where the member names in the object consist of the
    states from the city list. Each of those state object members should contain an
    array of city names that belong to that state. (in this test, most will only
    have one city). For extra credit: Pass latitude and longitude as parameters to
    this method, calculate the variance of each city from the given latitude and
    longitude, and then include this variance into the city lists.  (variance
    calculated as: Math.sqrt((citylatt – latt) * (citylatt – latt) + (citylong –
    long) * (citylong – long))   ).

*/

Map = function(data){

    // Compensate for js's.. um.. 'quirky' handling of object context.
    // (Keep a reference to 'this' object accessible even from within
    // functions, etc.)
    var my = this;  

    // To initialize, parse the data into an object of the form:
    //  {
    //      state_abbreviation: [
    //
    //              "cityname": {
    //                      latitude:   <xx.xx>,
    //                      longitude:  <yy.yy>
    //              },
    //
    //              "cityname2": {
    //                      latitude:   <xx.xx>,
    //                      longitude:  <yy.yy>
    //              }
    //                    
    //      ],
    //
    //      state_abbreviation2: [
    //
    //      . . .
    //  }
    //
    // This allows referencing a datum thus: 
    //      map_data[<state_abbreviation>][<cityname>].latitude

    my.data = {}; 
    for (i in data){
        var line = data[i];
        var match_data = line[0].match(/(\w.*), (\w{2})(\W|\b)/);
        var city = match_data[1];
        var state = match_data[2];
        var latitude = line[1];
        var longitude = line[2];

        if (!my.data[state]) { my.data[state] = {};};
        if (!my.data[state][city]) { my.data[state][city] = {};};

        my.data[state][city].latitude = latitude;
        my.data[state][city].longitude = longitude;

    }


    my.furthest = function(direction){
        // Return the <direction>-most location in the map. 
        // <direction> = [NSEW]

        if (!direction.match(/^[NSEW]$/)){ 
            console.log("Strange direction: " + direction);
            return null;
        };

        var winner;
        for (state in my.data){
            for(city in my.data[state]){
                if (typeof(winner) === "undefined" 
                    ||
                    my.is_further_than(my.data[state][city], winner, direction)){

                    winner = my.data[state][city];
                    retval = city + ", " + state;
                }
            }
        }
        return retval;
    };

    my.closest_to = function(position){
        // Return the city closest to the given coordinates.
        // <position> should contain properties 'latitude' and 'longitude'
        var smallest_variance = 91; // An impossibly high variance (for the quarter-sphere we're in)
        var closest_city = "Nowhere, XX";
        for (state in my.data){
            for(city in my.data[state]){
                var variance = my.variance(my.data[state][city],position);
                if (variance < smallest_variance){
                    smallest_variance = variance;
                    closest_city = city + ", " + state;
                }
            }
        }
        return closest_city;
    };

    my.state_abbreviations = function(){
        // Return a space-delimited string of unique state abbreviations from
        // the map data.
        var abbrevs = "";
        for(state in my.data){
            if (my.data.hasOwnProperty(state)){
                abbrevs += state + " ";
            }
        }
        return abbrevs.slice(0,-1); //Drop the last character (an unecessary space)
    };

    my.cities = function(position){
        // Return an object with a property per state that contains an array of
        // the cities within that state.
        var retval = {};
        for (state in my.data){
            retval[state] = [];
            for (city in my.data[state]){
                // If coordinates are given, include each city's variance from there.
                if (position){
                    city = {city:city, variance: my.variance(my.data[state][city],position)}
                }
                retval[state].push(city);
            }
        }
        
        return retval;
    }

    /*
     * Utility functions follow - may as well make them public here, as they seem generally useful.
     */
    my.is_further_than = function(a,b,direction){   
        // Return whether <a> is further <direction> than <b>.
        //
        // <a> and <b> are objects containing a 'latitude' and 'longitude'
        // <direction> is "N","S","E" or "W"
        //
        // CAVEAT: THIS ASSUMES THE NORTHERN AND WESTERN HEMISPHERES

        switch(direction){

            case "N":
                return a.latitude > b.latitude;
                break;

            case "S":
                return a.latitude < b.latitude;
                break;

            case "E":
                return a.longitude < b.longitude;
                break;

            case "W":
                return a.longitude > b.longitude;
                break;

            default:
                console.log("Strange direction:" + direction);
                return null;
                break;
        }
        
    }

    my.variance = function(p1,p2){
        // Calculate the distance between two locations.
        // Each position (p1,p2) is expected to have 'latitude' and 'longitude'
        // properties.
        // 
        // I can't help being bugged by the thought that this Pythagorean
        // formula may not apply precisely to the not-strictly-Euclidean
        // geometry of a globe.  (I am probably overthinking it.)
        var latt_diff = p1.latitude - p2.latitude;
        var long_diff = p1.longitude - p2.longitude;
        return Math.sqrt( (latt_diff * latt_diff) + (long_diff * long_diff));
    }

}
